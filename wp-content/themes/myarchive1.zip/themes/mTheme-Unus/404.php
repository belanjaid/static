<?php get_header(); ?>
<div class="fdx_topheading"><span class="fdx_prev">&lsaquo; <a href="<?php bloginfo('url'); ?>">Home</a></span> </div>
<div class="fdx_content">
<div align="center" style="padding: 30px 0 30px 0; "><strong style="font-size: 60px"><a href="#">404</a></strong><h1><?php _e('Page not found', 'wp-mobile-edition') ?> </h1>
</div>
</div>
<?php get_footer(); ?>