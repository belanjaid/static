<?php get_header(); ?>
<div class="fdx_topheading"><?php fdx_body_result_text();  ?></div>

<?php get_template_part('inc/index-blog'); ?>

<?php get_footer(); ?>